
import Fastify from 'fastify';
import Redis from 'ioredis';
import { z } from 'zod';
import process from 'node:process';
// import { drizzle } from 'drizzle-orm/postgres-js';
// import postgres from 'postgres';
// import * as schema from './db/schema'; // Hypothetical schema path

const REDIS_URL = process.env.REDIS_URL || 'redis://localhost:6379';
const DATABASE_URL = process.env.DATABASE_URL; // Required for DB operations
const REPO_ANALYSIS_QUEUE = 'repo_analysis_needed_queue';

const redis = new Redis(REDIS_URL);
const fastify = Fastify({ logger: true });

// Placeholder for Drizzle client
// let db: any; 
// if (DATABASE_URL) {
//   const queryClient = postgres(DATABASE_URL);
//   db = drizzle(queryClient /*, { schema } */);
// } else {
//   fastify.log.warn('DATABASE_URL not set, database operations will be simulated.');
// }

// Basic health check
fastify.get('/health', async (request, reply) => {
  return { status: 'ok', service: 'github-app-service' };
});

const ProcessRepoSchema = z.object({
  repoUrl: z.string().url(),
});

fastify.post('/api/process-repo', async (request, reply) => {
  if (!DATABASE_URL) { // Check moved here to ensure it's available for this endpoint.
    fastify.log.error("DATABASE_URL environment variable is not set. GitHub App Service cannot fully process requests.");
    return reply.status(500).send({ error: 'Server configuration error: Database not configured.' });
  }
  try {
    const validatedBody = ProcessRepoSchema.safeParse(request.body);
    if (!validatedBody.success) {
      return reply.status(400).send({ error: "Invalid request body", details: validatedBody.error.flatten() });
    }
    const { repoUrl } = validatedBody.data;

    const projectId = crypto.randomUUID(); 

    // ** 1. Create initial record in 'generated_sites' table **
    try {
      // Conceptual DB insert. Replace with actual Drizzle call when DB client is live.
      // await db.insert(schema.generatedSites).values({ 
      //   id: projectId, 
      //   repoUrl: repoUrl, 
      //   status: 'PENDING_ANALYSIS',
      //   createdAt: new Date(), // Drizzle might handle this with defaultSQL
      //   updatedAt: new Date() 
      // });
      fastify.log.info(`(Conceptual DB) Inserted into generated_sites: ID ${projectId}, URL ${repoUrl}, Status PENDING_ANALYSIS`);
    } catch (dbError) {
      fastify.log.error(dbError, `Failed to create initial record in generated_sites for project ${projectId}`);
      return reply.status(500).send({ error: 'Failed to initialize project processing in database.' });
    }

    // ** 2. Enqueue job for AI Analysis Pipeline **
    const jobData = {
      projectId,
      repoUrl,
      requestedAt: new Date().toISOString(),
    };
    await redis.lpush(REPO_ANALYSIS_QUEUE, JSON.stringify(jobData));
    fastify.log.info(`Job for ${repoUrl} (Project ID: ${projectId}) enqueued to ${REPO_ANALYSIS_QUEUE}`);

    return reply.status(202).send({ 
      message: 'Repository analysis queued.', 
      projectId: projectId,
      repoUrl: repoUrl 
    });

  } catch (error) {
    fastify.log.error(error, 'Error in /api/process-repo');
    return reply.status(500).send({ error: 'Internal Server Error' });
  }
});

const start = async () => {
  try {
    const port = process.env.PORT ? parseInt(process.env.PORT) : 3001;
    await fastify.listen({ port, host: '0.0.0.0' });
    fastify.log.info(`GitHub App Service listening on port ${port}`);
  } catch (err) {
    fastify.log.error(err);
    process.exit(1);
  }
};

redis.on('connect', () => fastify.log.info('GitHub App Service connected to Redis.'));
redis.on('error', (err) => fastify.log.error('Redis connection error in GitHub App Service:', err));

start();