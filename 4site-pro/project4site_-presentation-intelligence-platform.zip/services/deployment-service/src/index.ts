
import Fastify from 'fastify';
import Redis from 'ioredis';
import { drizzle } from 'drizzle-orm/postgres-js';
import postgres from 'postgres';
import process from 'node:process';
// import * as schema from './db/schema'; // To be created for Drizzle

const REDIS_URL = process.env.REDIS_URL || 'redis://localhost:6379';
const DATABASE_URL = process.env.DATABASE_URL!; // Must be set
const DEPLOY_SITE_QUEUE = 'deploy_site_queue';

const redis = new Redis(REDIS_URL);
const fastify = Fastify({ logger: true });

// const queryClient = postgres(DATABASE_URL);
// const db = drizzle(queryClient, { schema }); // Initialize Drizzle

interface DeployJobData {
  projectId: string;
  generatedSiteId: string;
  contentVersionId: string;
  // path_to_static_bundle: string; // This would come from Site Generation Engine
  // template: string;
}

// Basic health check
fastify.get('/health', async (request, reply) => {
  return { status: 'ok', service: 'deployment-service' };
});

async function processDeploymentJobs() {
  fastify.log.info(`Deployment Service: Worker started, listening to queue: ${DEPLOY_SITE_QUEUE}`);
  // TODO: Implement database connection and Drizzle ORM setup
  
  // Placeholder for DB client
  const dbClient = {
      updateGeneratedSiteStatus: async (siteId: string, deployedUrl: string, status: string) => {
          fastify.log.info(`DB: Updating site ${siteId} with URL ${deployedUrl} and status ${status}`);
          // Example: await db.update(schema.generatedSites).set({ deployedUrl, status, lastDeployedAt: new Date() }).where(eq(schema.generatedSites.id, siteId));
      }
  };

  while (true) { // Replaced 'loop' with 'while (true)'
    try {
      const jobStr = await redis.rpop(DEPLOY_SITE_QUEUE); // Using rpop for simplicity; consider brpop for production

      if (jobStr) {
        fastify.log.info(`Received deployment job: ${jobStr}`);
        const jobData: DeployJobData = JSON.parse(jobStr);

        fastify.log.info(`Processing deployment for project ID: ${jobData.projectId}, site ID: ${jobData.generatedSiteId}`);

        // 1. Placeholder: "Retrieve" static site bundle path (this would be passed in jobData)
        const bundlePath = `/path/to/bundles/${jobData.generatedSiteId}`; 
        fastify.log.info(`Simulating deployment for bundle at ${bundlePath}`);

        // 2. Placeholder: Interact with CDN API (Vercel, Cloudflare Pages, etc.)
        // const cdnToken = process.env.VERCEL_TOKEN; // Example
        // if (!cdnToken) {
        //   fastify.log.error("CDN token not configured. Cannot deploy.");
        //   // Potentially re-queue or mark as failed
        //   continue;
        // }
        // const deployedUrl = await deployToCDN(bundlePath, jobData.projectId, cdnToken);
        
        // Simulate deployment success
        await new Promise(resolve => setTimeout(resolve, 2000)); // Simulate network latency
        const deployedUrl = `https://${jobData.projectId.substring(0,8)}.project4.site`; // Dummy URL

        fastify.log.info(`Site ${jobData.generatedSiteId} "deployed" to ${deployedUrl}`);

        // 3. Update database with deployment URL and status
        await dbClient.updateGeneratedSiteStatus(jobData.generatedSiteId, deployedUrl, 'live');
        
        fastify.log.info(`Deployment complete for site ID ${jobData.generatedSiteId}.`);

      } else {
        // Queue is empty, wait a bit
        await new Promise(resolve => setTimeout(resolve, 1000));
      }
    } catch (error) {
      fastify.log.error(error, 'Error processing deployment job');
      // Implement more robust error handling (e.g., dead-letter queue, retries)
      await new Promise(resolve => setTimeout(resolve, 5000)); // Wait longer on error
    }
  }
}

const start = async () => {
  if (!DATABASE_URL) {
    fastify.log.error("DATABASE_URL environment variable is not set. Deployment service cannot start.");
    process.exit(1);
  }

  // Run job processor in background, with error handling for the async task itself
  processDeploymentJobs().catch(err => {
    fastify.log.error(err, 'Unhandled error in processDeploymentJobs background task');
    process.exit(1); // Exit if the core background task fails catastrophically
  });

  try {
    const port = process.env.PORT ? parseInt(process.env.PORT) : 3003;
    await fastify.listen({ port, host: '0.0.0.0' });
    fastify.log.info(`Deployment Service listening on port ${port}`);
  } catch (err) {
    fastify.log.error(err);
    process.exit(1);
  }
};

redis.on('connect', () => fastify.log.info('Deployment Service connected to Redis.'));
redis.on('error', (err) => fastify.log.error('Redis connection error in Deployment Service:', err));

start();