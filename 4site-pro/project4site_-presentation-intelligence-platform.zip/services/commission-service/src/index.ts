
import Fastify from 'fastify';
import Redis from 'ioredis';
import { z } from 'zod';
import { PARTNER_CONFIGS, PartnerConfig, AttributionData } from './config_and_types';
import process from 'node:process';
// import { drizzle } from 'drizzle-orm/postgres-js'; // Drizzle for DB
// import postgres from 'postgres';
// import * as schema from './db/schema'; // Drizzle schema

const REDIS_URL = process.env.REDIS_URL || 'redis://localhost:6379';
// const DATABASE_URL = process.env.DATABASE_URL!;

const redis = new Redis(REDIS_URL);
const fastify = Fastify({ logger: true });

// const queryClient = postgres(DATABASE_URL);
// const db = drizzle(queryClient, { schema });

const ATTRIBUTION_WINDOW_HOURS = 24 * 30; // 30 days attribution window

class ReferralCodeGenerator {
  static generateReferralUrl(partnerId: string, userId?: string, projectId?: string): string | null {
    const partnerConfig = PARTNER_CONFIGS[partnerId];
    if (!partnerConfig) {
      fastify.log.warn(`No partner config found for ID: ${partnerId}`);
      return null;
    }

    let referralCode = partnerConfig.referralParameter;
    // Potentially append userId or projectId to the referral code if partner supports sub-IDs
    // e.g., ref=project4site&subid1={userId}&subid2={projectId}
    // This depends on partner's program. For now, using the base referralParameter.

    // Ensure landingPage ends with a / if referralParameter doesn't start with ? or &
    let landingPage = partnerConfig.landingPage;
    if (!landingPage.endsWith('/') && !referralCode.startsWith('?') && !referralCode.startsWith('&')) {
        landingPage += '/';
    }
    
    // Check if referral code already contains '?'
    const separator = landingPage.includes('?') ? '&' : '?';
    
    // If referralParameter is already a full query string part like 'ref=project4site'
    if (referralCode.includes('=')) {
         return `${landingPage}${separator}${referralCode}`;
    } else {
        // If referralParameter is just the value like 'project4site' and we need to form 'ref=project4site'
        // This case needs a default parameter name, e.g. 'ref'
        // For simplicity, assuming referralParameter is self-contained like 'ref=project4site' or 'via=project4site'
        fastify.log.error(`Referral parameter for ${partnerId} is not a full query string part: ${referralCode}. Fix config.`);
        return `${landingPage}${separator}${referralCode}`; // Might be incorrect
    }
  }
}

class AttributionTracker {
  static async trackClick(
    partnerId: string, 
    referralUrl: string,
    ipAddress?: string, 
    userAgent?: string,
    userId?: string,
    projectId?: string,
    generatedSiteId?: string,
  ): Promise<string | null> {
    const partnerConfig = PARTNER_CONFIGS[partnerId];
    if (!partnerConfig) {
      fastify.log.error(`Cannot track click for unknown partner: ${partnerId}`);
      return null;
    }

    const clickId = crypto.randomUUID();
    const clickTimestamp = new Date();
    const attributionWindowEnds = new Date(clickTimestamp.getTime() + ATTRIBUTION_WINDOW_HOURS * 60 * 60 * 1000);

    const attributionData: AttributionData = {
      id: clickId,
      userId,
      projectId,
      generatedSiteId,
      partnerId,
      referralCodeUsed: partnerConfig.referralParameter, // Simplified, extract actual code if more complex
      fullReferralUrl: referralUrl,
      ipAddress,
      userAgent,
      clickTimestamp,
      status: 'clicked',
      attributionWindowEnds,
      metadata: { /* any other query params from referralUrl */ }
    };

    try {
      // Store in Redis for short-term (e.g., session-based or quick lookups)
      // Convert numeric duration to string to satisfy TypeScript error, though Redis EX usually takes a number.
      await redis.set(`attribution:click:${clickId}`, JSON.stringify(attributionData), 'EX', String(ATTRIBUTION_WINDOW_HOURS * 60 * 60));
      // Store in PostgreSQL for long-term persistence (Drizzle insert)
      // await db.insert(schema.partnerReferrals).values(attributionData);
      fastify.log.info(`Tracked click ID ${clickId} for partner ${partnerId}. Storing in DB (simulated).`);
      // Simulating DB storage for Phase 1 without full Drizzle setup in this file
      console.log("DB INSERT (Simulated):", attributionData);


      return clickId;
    } catch (error) {
      fastify.log.error(error, `Failed to track click for partner ${partnerId}`);
      return null;
    }
  }
}


// HTTP Endpoints
fastify.get('/health', async (request, reply) => {
  return { status: 'ok', service: 'commission-service' };
});

// Endpoint to generate a referral link (e.g., for site generator to embed)
const GenerateLinkSchema = z.object({
  partnerId: z.string(),
  userId: z.string().optional(),
  projectId: z.string().optional(),
});
fastify.post('/api/generate-referral-link', async (request, reply) => {
  const validation = GenerateLinkSchema.safeParse(request.body);
  if (!validation.success) {
    return reply.status(400).send({ error: "Invalid request", details: validation.error.flatten() });
  }
  const { partnerId, userId, projectId } = validation.data;
  const url = ReferralCodeGenerator.generateReferralUrl(partnerId, userId, projectId);
  if (url) {
    return { referralUrl: url };
  } else {
    return reply.status(404).send({ error: "Partner not found or misconfigured" });
  }
});

// Endpoint to record a click (e.g., when user clicks a referral link)
// This might be a redirecting endpoint itself.
const TrackClickSchema = z.object({
  partnerId: z.string(),
  userId: z.string().optional(),
  projectId: z.string().optional(),
  generatedSiteId: z.string().optional(),
  // referralUrl: z.string().url().optional(), // The URL they are going to
});

fastify.get('/track/:partnerId', async (request, reply) => {
    const params = request.params as { partnerId: string };
    const query = request.query as { userId?: string, projectId?: string, siteId?: string, dest?: string };

    const partnerId = params.partnerId;
    const partnerConfig = PARTNER_CONFIGS[partnerId];

    if (!partnerConfig) {
        return reply.status(404).send({ error: "Partner not found" });
    }
    
    // Construct the actual destination URL
    // The 'dest' query param can be used if the landing page has variations not in PartnerConfig
    let destinationUrl = query.dest || partnerConfig.landingPage;
    const referralUrl = ReferralCodeGenerator.generateReferralUrl(partnerId, query.userId, query.projectId);
    
    if (!referralUrl) {
         return reply.status(500).send({ error: "Could not generate referral URL for partner." });
    }
    
    // Use the referral URL generated (which includes the base landing page and params) as the destination
    destinationUrl = referralUrl;


    await AttributionTracker.trackClick(
        partnerId,
        destinationUrl, // This is the full URL they are redirected to
        request.ip,
        request.headers['user-agent'],
        query.userId,
        query.projectId,
        query.siteId
    );
    
    fastify.log.info(`Redirecting to: ${destinationUrl}`);
    reply.redirect(302, destinationUrl);
});


// Placeholder for Partner Webhook Ingestion (e.g., for Railway success events)
fastify.post('/webhooks/:partnerId', async (request, reply) => {
  const params = request.params as { partnerId: string };
  const partnerId = params.partnerId;
  const partnerConfig = PARTNER_CONFIGS[partnerId];

  if (!partnerConfig || partnerConfig.successEventDefinition.type !== 'WEBHOOK') {
    return reply.status(404).send({ error: "Webhook not configured for this partner" });
  }

  // TODO: Implement webhook verification (HMAC, API Key) based on partnerConfig
  // Example: if (partnerConfig.successEventDefinition.webhookVerificationMethod === 'HMAC_SHA256') { ... }
  
  const payload = request.body;
  fastify.log.info(`Received webhook for partner ${partnerId}:`, payload);

  // TODO: Process payload to identify success event and user
  // Extract status, user ID from payload using payloadPathToStatus, payloadUserIdPath
  // Calculate commission if it's a billable success event.
  // Store SuccessEvent in PostgreSQL.

  return reply.status(200).send({ message: "Webhook received" });
});


const start = async () => {
  // if (!DATABASE_URL) {
  //   fastify.log.error("DATABASE_URL environment variable is not set. Commission service may not function fully.");
  //   // process.exit(1); // Or run in a degraded mode for some features
  // }
  try {
    const port = process.env.PORT ? parseInt(process.env.PORT) : 3004;
    await fastify.listen({ port, host: '0.0.0.0' });
    fastify.log.info(`Commission Service listening on port ${port}`);
  } catch (err) {
    fastify.log.error(err);
    process.exit(1);
  }
};

redis.on('connect', () => fastify.log.info('Commission Service connected to Redis.'));
redis.on('error', (err) => fastify.log.error('Redis connection error in Commission Service:', err));

start();